function register() {

	var u = document.getElementById("username1").value
 
	var p = document.getElementById("pass1").value
 
	var e = document.getElementById("emails").value
 
	var r = "user";
 
	var newobj = {
 
	   username: u,
 
	   email: e,
 
	   role: r,
 
	   password: p
 
	}
 
	var req = new XMLHttpRequest();
 
	req.open("POST", "http://localhost:2000/register", true);
 
	req.setRequestHeader("Content-type", "application/json");
 
  
 
	req.send(JSON.stringify(newobj));
 
	req.onreadystatechange = function () {
 
	   if (req.readyState == 4) {
 
		  if (req.status == 201) {
			
			//  console.log(JSON.stringify(req.response));
            //  alert("Register SUccess");
			//  loadUser();
			window.location.href = "login.html";
		  }
 
	   }
 
	}
 
  
 
 }
 
  
 
  
 
  
 
  
 
  
 
  
 
  
 
 function adminlogin() {
 
	
 
	var g = document.getElementById("ls1").value;
 
	var h = document.getElementById("passs1").value;
 
	
 
	var req = new XMLHttpRequest();
 
	var newobj = {
 
	   username: g,
 
	   password: h,


 
	}
 
  
 
	req.open("POST", "http://localhost:2000/login1", true);
 
	req.setRequestHeader("Content-type", "application/json");
 
	req.send(JSON.stringify(newobj));
 
	req.onreadystatechange = function () {
 
	   if (req.readyState == 4) {
 
		  if (req.status == 200) {
 
			 var k = JSON.parse(req.responseText);
 
			 console.log(k.token);
        
          
 
			  localStorage.setItem("Token",k.token);
			//   localStorage.setItem("Username",k.user.username);
		//   localStorage.setItem('Email',k.user.email)
			 loadAdmin();
 
  
 
			 
 
  
 
		  }
 
	   }
 
 
 }
 
}
 
  
 
  
 
 function login() {
 
	var u = document.getElementById("l1").value;
 
	var p = document.getElementById("p1").value;
 
	var req = new XMLHttpRequest();
 
	var newobj = {
 
	   username: u,
 
	   password: p
 
	}
 
  
 
	req.open("POST", "http://localhost:2000/login", true);
 
	req.setRequestHeader("Content-type", "application/json");
 
	req.send(JSON.stringify(newobj));
 
	req.onreadystatechange = function () {
 
	   if (req.readyState == 4) {
 
		  if (req.status == 200) {
 
			 var k = JSON.parse(req.responseText);
 
			 console.log(k.token);
          console.log(k.user.username);
          
 
			  localStorage.setItem("Token",k.token);
          localStorage.setItem("Username",k.user.username);
		//   localStorage.setItem('Email',k.user.email)
		loadUser();
 
  
 
			 
 
  
 
		  }
 
	   }
 
  
 
	}
 
  
 
  
 
  
 
 }
 
  
 
 function loadUser(){
 
	var req = new XMLHttpRequest();
 
  
 
	req.open("GET", "http://localhost:2000/auth-user", true);
 
	req.setRequestHeader("Content-type", "application/json");
 
	req.setRequestHeader("x-user-auth-token",localStorage.getItem("Token"));
 
  
 
	req.send();
 
	req.onreadystatechange = function () {
 
	   if (req.readyState == 4) {
 
		  if (req.status == 200) {
 
			
			window.location.href = "book.html";
  
 
		  }
 
	   }
 
  
 
	}
 
  
}
 
function loadAdmin(){
 
	var req = new XMLHttpRequest();
 
  
 
	req.open("GET", "http://localhost:2000/auth-admin", true);
 
	req.setRequestHeader("Content-type", "application/json");
 
	req.setRequestHeader("x-admin-auth-token",localStorage.getItem("Token"));
 
  
 
	req.send();
 
	req.onreadystatechange = function () {
 
	   if (req.readyState == 4) {
 
		  if (req.status == 200) {
 
			
			window.location.href = "event.html";
  
 
		  }
 
	   }
 
  
 
	}
 
  
 
  
 
  
 
 }