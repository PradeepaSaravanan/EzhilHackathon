 const express = require("express");
const dotenv = require("dotenv");
const logger = require("morgan");
const cors = require("cors");
var jwtlib = require('jsonwebtoken');
require("colors");

const db = require("./config/db");

const app = express();

dotenv.config({ path: "./config/config.env" });

if (process.env.NODE_ENV === "production") console.log = function() {};

if (process.env.NODE_ENV === "development") app.use(logger("dev"));

app.use(cors());
app.use(express.static("./public"))
// DB Connection
db(app);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use( require("./controller/user"));
app.use(require("./controller/admin"));
app.use(require("./controller/book"));
app.use(require("./controller/event.js"));
module.exports = app;

var user;
function generateJWTForOTTBot(){
    const payload = {
      "iat": (new Date().getTime())/1000,
      "exp": (new Date().getTime())/1000+86400,
        "aud": "https://idproxy.kore.ai/authorize",
        "iss": "cs-58c0f6fa-7b7b-5da0-9db2-b523281ad52c",
      "sub": user
    }
    const secret = "R7+ZwWJE+CdSpIh0SWWlxMxCQc+1rOUtt4x9ATy/dmg=";
    var token = jwtlib.sign(payload, secret);
    return token;
  }

  app.get('/sts', (req, res) => {
    res.set( {
    'Content-Type': 'application/json',
    "Access-Control-Allow-Origin":"*",
    "Access-Control-Allow-Headers":"*",
    "Access-Control-Allow-methods":"*"}); const jwt = generateJWTForOTTBot();
    data = {
    jwt:jwt
    };
    let userToken=req.get("Authorization");
    user=verifyUsertoken(userToken);
res.send(JSON.stringify(data));
  
  })


  function verifyUsertoken(userToken){
            let decode=jwtlib.decode(userToken,{complete:true});
            console.log(decode);
            if(decode.payload.admin){
              return decode.payload.admin.email;
            }
            // console.log(decode.payload.user.username);
            // console.log(decode.payload.user.email);
          else{
              return decode.payload.user.email;
            }
           
          }